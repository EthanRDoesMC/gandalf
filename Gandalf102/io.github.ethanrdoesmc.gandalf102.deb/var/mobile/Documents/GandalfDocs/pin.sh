#!/bin/bash

echo io.github.ethanrdoesmc.gandalf102 hold | dpkg --set-selections
