#!/bin/bash

echo io.github.ethanrdoesmc.gandalf102 install | dpkg --set-selections
